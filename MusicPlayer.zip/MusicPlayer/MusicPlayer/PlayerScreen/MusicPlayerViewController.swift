//
//  MusicPlayerViewController.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import UIKit
import AVFoundation

final class MusicPlayerViewController: UIViewController {

    static func instantiate(with media: Media) -> MusicPlayerViewController? {
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        let viewController = storyboard.instantiateViewController(withIdentifier: "MusicPlayerViewController") as? MusicPlayerViewController
        viewController?.viewModel = MusicPlayerViewModel(view: viewController, media: media)
        return viewController
    }

    // MARK: - Properties
    var audioPlayer: AVAudioPlayer?
    private(set) var viewModel: MusicPlayerViewModel!

    // MARK: - Outlets
    @IBOutlet weak var audioTitleLabel: UILabel!
    @IBOutlet weak var playPauseButton: UIButton!

    // MARK: - Button Actions
    @IBAction func backButtonAction() {
        resetData()
        navigationController?.popViewController(animated: true)
    }

    @IBAction func playPauseButtonAction() {
        viewModel.toggleAudioState()
    }

    // MARK: - View LifeCucle Methods
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        viewModel.toggleAudioState()
        audioTitleLabel.text = viewModel.media.title
    }

    deinit {
        resetData()
    }

    // MARK: - Helper Methods
    func resetData() {
        audioPlayer?.stop()
        audioPlayer = nil
    }
}

extension MusicPlayerViewController: MusicPlayerViewInterface {
    func initAduioPlayer(url: URL) throws {
        audioPlayer = try AVAudioPlayer(contentsOf: url)
    }

    func playAudio() {
        audioPlayer?.play()
    }

    func pauseAudio() {
        audioPlayer?.pause()
    }

    func updatePlayButton(title: String) {
        playPauseButton.setTitle(title, for: .normal)
    }
}
