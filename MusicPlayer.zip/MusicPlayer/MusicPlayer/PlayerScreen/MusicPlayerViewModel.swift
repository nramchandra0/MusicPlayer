//
//  MusicPlayerViewModel.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import Foundation

protocol MusicPlayerViewInterface: AnyObject {
    func initAduioPlayer(url: URL) throws
    func playAudio()
    func pauseAudio()
    func updatePlayButton(title: String)
}

final class MusicPlayerViewModel {

    // MARK: - Properties
    weak var view: MusicPlayerViewInterface?
    let media: Media
    private(set) var playing: Bool = false

    // MARK: - Initialization
    init(view: MusicPlayerViewInterface?, media: Media) {
        self.view = view
        self.media = media

        if let url = URL(string: media.url) {
            try? view?.initAduioPlayer(url: url)
        }
    }

    // MARK: - Helper Methods
    func toggleAudioState() {
        if playing {
            view?.pauseAudio()
        } else {
            view?.playAudio()
        }
        playing.toggle()
        updatePlayButton()
    }

    func updatePlayButton() {
        let title = playing ? "Pause" : "Play"
        view?.updatePlayButton(title: title)
    }
}
