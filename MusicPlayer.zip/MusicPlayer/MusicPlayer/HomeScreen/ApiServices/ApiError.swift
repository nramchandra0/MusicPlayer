//
//  ApiError.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import Foundation

enum ApiError: Error {
    case invalidURL
    case parsingError
    case unknownError
}
