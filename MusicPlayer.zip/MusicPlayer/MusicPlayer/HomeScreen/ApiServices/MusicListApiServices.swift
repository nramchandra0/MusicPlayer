//
//  MusicListApiServices.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import Foundation

protocol MusicListApiServicesProtocol: AnyObject {
    func fetchMusicList(_ completion: @escaping (Result<MediaResponseModel, Error>) -> Void)
}

class MusicListApiServices: MusicListApiServicesProtocol {

    func fetchMusicList(_ completion: @escaping (Result<MediaResponseModel, Error>) -> Void) {
        guard let url = URL(string: "https://www.jsonkeeper.com/b/LPEV") else {
            completion(.failure(ApiError.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    let response = try JSONDecoder().decode(MediaResponseModel.self, from: data)
                    completion(.success(response))
                } catch {
                    completion(.failure(ApiError.parsingError))
                }
            } else if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(ApiError.unknownError))
            }
        }
        .resume()
    }
}
