//
//  MediaResponseModel.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import Foundation

struct MediaResponseModel: Decodable {
    var array: [Media]
}
