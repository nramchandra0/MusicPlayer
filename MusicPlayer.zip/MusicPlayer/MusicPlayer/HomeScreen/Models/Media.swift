//
//  Media.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import Foundation

struct Media: Decodable {
    var title: String
    var album: String
    var artist: String
    var url: String
}
