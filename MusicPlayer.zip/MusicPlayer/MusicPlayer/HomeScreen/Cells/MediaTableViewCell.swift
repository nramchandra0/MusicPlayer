//
//  MediaTableViewCell.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import UIKit

final class MediaTableViewCell: UITableViewCell {

    // MARK: - Outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var albumLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!

    // MARK: - View LifeCycle Methods
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    // MARK: - Helper Methods
    func configureCell(with media: Media) {
        titleLabel.text = media.title
        albumLabel.text = "Album:" + media.album
        artistLabel.text = "Artist:" + media.artist
    }
}
