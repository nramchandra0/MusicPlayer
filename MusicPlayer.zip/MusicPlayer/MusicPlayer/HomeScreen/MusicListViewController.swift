//
//  MusicListViewController.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import UIKit

final class MusicListViewController: UIViewController {

    // MARK: - Properties
    lazy var viewModel: MusicListViewModel = {
        MusicListViewModel(view: self)
    }()

    // MARK: - Outlets
    @IBOutlet weak var musicListTableView: UITableView!

    // MARK: - View LifeCycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        navigationItem.title = "Music List"
        setupTableView()
        viewModel.fetchData()
    }

    // MARK: - Helper Methods
    func setupTableView() {
        let cellNib = UINib(nibName: "MediaTableViewCell", bundle: .main)
        musicListTableView.register(cellNib, forCellReuseIdentifier: "MediaTableViewCell")
        musicListTableView.dataSource = self
        musicListTableView.delegate = self
    }
}

extension MusicListViewController: MusicListViewInterface {
    func reloadData() {
        DispatchQueue.main.async {
            self.musicListTableView.reloadData()
        }
    }

    func showMusicPlayer(media: Media) {
        if let viewController = MusicPlayerViewController.instantiate(with: media) {
            navigationController?.pushViewController(viewController, animated: true)
        }
    }
}

extension MusicListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.musicList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "MediaTableViewCell") as? MediaTableViewCell {
            let media = viewModel.mediaForCell(at: indexPath)
            cell.configureCell(with: media)
            return cell
        }
        return UITableViewCell()
    }
}

extension MusicListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        viewModel.didSelectMusicCell(at: indexPath)
    }
}
