//
//  MusicListViewModel.swift
//  MusicPlayer
//
//  Created by Ramchandra Nagalapelli on 21/10/23.
//

import Foundation

protocol MusicListViewInterface: AnyObject {
    func reloadData()
    func showMusicPlayer(media: Media)
}

final class MusicListViewModel {

    // MARK: - Properties
    let apiServices: MusicListApiServicesProtocol
    weak var view: MusicListViewInterface?
    private(set) var musicList: [Media] = []

    // MARK: - Initialization
    init(view: MusicListViewInterface?, apiServices: MusicListApiServicesProtocol = MusicListApiServices()) {
        self.view = view
        self.apiServices = apiServices
    }

    // MARK: - Helper Methods
    func fetchData() {
        apiServices.fetchMusicList { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let response):
                self.musicList = response.array
                self.view?.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }

    func mediaForCell(at indexPath: IndexPath) -> Media {
        return musicList[indexPath.row]
    }

    func didSelectMusicCell(at indexPath: IndexPath) {
        view?.showMusicPlayer(media: mediaForCell(at: indexPath))
    }
}
